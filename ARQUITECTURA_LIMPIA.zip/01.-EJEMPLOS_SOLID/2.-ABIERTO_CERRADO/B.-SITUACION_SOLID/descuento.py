class Descuento:
    def aplicar_descuento(self, monto):
        raise NotImplementedError("Este método debe ser implementado por las subclases")