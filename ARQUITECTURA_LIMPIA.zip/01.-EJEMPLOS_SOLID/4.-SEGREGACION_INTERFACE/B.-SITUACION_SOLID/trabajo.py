class Trabajo:
    def trabajar(self):
        raise NotImplementedError("Este método debe ser implementado por las subclases")