class Reporte:
    def reportar(self):
        raise NotImplementedError("Este método debe ser implementado por las subclases")