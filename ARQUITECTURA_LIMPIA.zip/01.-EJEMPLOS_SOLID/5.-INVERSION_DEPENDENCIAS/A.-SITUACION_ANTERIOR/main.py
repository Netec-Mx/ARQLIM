from procesador_ordenes import ProcesadorOrdenes

# Uso
if __name__ == "__main__":
    procesador = ProcesadorOrdenes()
    procesador.procesar("Orden #1")