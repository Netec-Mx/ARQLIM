class Ave:
    def volar(self):
        return "Estoy volando"