from ave import Ave

class Pinguino(Ave):
    def volar(self):
        raise NotImplementedError("Los pingüinos no pueden volar")