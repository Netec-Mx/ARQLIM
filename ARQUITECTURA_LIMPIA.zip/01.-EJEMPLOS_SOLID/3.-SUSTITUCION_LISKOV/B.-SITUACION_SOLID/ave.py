class Ave:
    def moverse(self):
        raise NotImplementedError("Este método debe ser implementado por las subclases")