class CalculadoraSalario:
    def calcular_salario(self, empleado, horas_extras):
        return empleado.calcular_salario(horas_extras)