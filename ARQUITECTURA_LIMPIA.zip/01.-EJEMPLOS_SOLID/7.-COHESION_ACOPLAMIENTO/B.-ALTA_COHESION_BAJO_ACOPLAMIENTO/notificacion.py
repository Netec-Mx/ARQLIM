class Notificador:
    def enviar_notificacion(self, empleado, mensaje):
        print(f"Enviando notificación a {empleado.nombre}: {mensaje}")