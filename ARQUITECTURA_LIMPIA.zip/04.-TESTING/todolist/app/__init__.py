# Este archivo puede estar vacío.
# Su propósito es indicar que el directorio es un paquete Python.